import mysql.connector
from mysql.connector import Error


class Database():
    def __init__(self,
                 host="localhost",
                 port="3307",
                 database="teachers_portal",
                 user='root',
                 password='Firms@2215'):

        self.host       = host
        self.port       = port
        self.database   = database
        self.user       = user
        self.password   = password
        self.connection = None
        self.cursor     = None
        self.connect()

    def connect(self):
        try:
            self.connection = mysql.connector.connect(
                host         = self.host,
                port         = self.port,
                database     = self.database,
                user         = self.user,
                password     = self.password)
            
            if self.connection.is_connected():
                return
        except Error as e:
            print("Error while connecting to MySQL", e)
    

    def getAllStudents(self):
        if self.connection.is_connected():
            self.cursor= self.connection.cursor();
            self.cursor.callproc("studentsWithGrade")
            records = self.cursor.stored_results()
            return records

    def addStudent(self, name, courseID, grade=0):
        if self.connection.is_connected():
            self.cursor= self.connection.cursor();
            add_student = ("INSERT INTO students (studentName, enrolledInCourseID, grade)" 
                                    "VALUES (%s, %s, %s)")

            record = (name, courseID, grade)

            # add new student
            self.cursor.execute(add_student, record)
            studentId = self.cursor.lastrowid

            # commit to database
            self.connection.commit()

            # close cursor and connection
            self.cursor.close()
            self.connection.close()            
            pass
    def addCourse(self, name):
        if self.connection.is_connected():
            self.cursor= self.connection.cursor();
            add_course = ("INSERT INTO courses (courseName)" 
                                    "VALUES (%s)")

            record = (name)

            # add new course
            self.cursor.execute(add_course, (record,))
            courseId = self.cursor.lastrowid

            # commit to database
            self.connection.commit()

            # close cursor and connection
            self.cursor.close()
            self.connection.close()
            pass
    
    def modifyGrade(self, studentID, grade):
            cnx = mysql.connector.connect(host="localhost", user='root', password="123", database='teachers_portal')
            cursor = cnx.cursor()  
            cursor.execute("UPDATE students SET studentName=%s, grade=%s", (self.studentName.get(), self.grade.get(),  ))
            pass

    def searchStudent(self, s_id):
        if self.connection.is_connected():
            self.cursor= self.connection.cursor();
            self.cursor.callproc("searchStudentById", (s_id,))
            records = self.cursor.stored_results()
            return records
            
        
